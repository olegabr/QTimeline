<?php
	/**
	 * The abstract QTimelineGen class
	 */
	abstract class QTimelineGen extends QPanel	{
//		protected $strJavaScripts = __JQUERY_EFFECTS__;
//		protected $strStyleSheets = __JQUERY_CSS__;
	}

?>
